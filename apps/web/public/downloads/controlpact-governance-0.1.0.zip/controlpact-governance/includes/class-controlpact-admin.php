<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class ControlPact_Admin {
    /**
     * Register admin hooks.
     */
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_post_controlpact_save_settings', array( $this, 'save_settings' ) );
        add_action( 'admin_post_controlpact_test_connection', array( $this, 'test_connection' ) );
    }

    /**
     * Register the settings page.
     */
    public function register_menu() {
        add_options_page(
            __( 'ControlPact', 'controlpact-governance' ),
            __( 'ControlPact', 'controlpact-governance' ),
            'manage_options',
            'controlpact',
            array( $this, 'render_page' )
        );
    }

    /**
     * Render the settings page.
     */
    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $has_key = '' !== trim( (string) get_option( CONTROLPACT_OPTION_API_KEY, '' ) );

        $notice = isset( $_GET['controlpact_notice'] )
            ? sanitize_key( wp_unslash( $_GET['controlpact_notice'] ) )
            : '';

        $decision = isset( $_GET['controlpact_decision'] )
            ? sanitize_text_field( wp_unslash( $_GET['controlpact_decision'] ) )
            : '';
        ?>

        <div class="wrap">
            <h1><?php esc_html_e( 'ControlPact Governance', 'controlpact-governance' ); ?></h1>

            <p>
                <?php esc_html_e( 'Connect this WordPress site to your ControlPact organisation using your own scoped Production API key.', 'controlpact-governance' ); ?>
            </p>

            <?php if ( 'saved' === $notice ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e( 'ControlPact settings saved.', 'controlpact-governance' ); ?></p>
                </div>
            <?php elseif ( 'connected' === $notice ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p>
                        <?php esc_html_e( 'Connected to ControlPact. Decision returned:', 'controlpact-governance' ); ?>
                        <strong><?php echo esc_html( $decision ); ?></strong>
                    </p>
                </div>
            <?php elseif ( 'error' === $notice ) : ?>
                <div class="notice notice-error is-dismissible">
                    <p><?php echo esc_html( $decision ); ?></p>
                </div>
            <?php endif; ?>

            <h2><?php esc_html_e( 'Connection', 'controlpact-governance' ); ?></h2>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="controlpact_save_settings">

                <?php wp_nonce_field( 'controlpact_save_settings' ); ?>

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">
                            <label for="controlpact_api_key">
                                <?php esc_html_e( 'ControlPact API Key', 'controlpact-governance' ); ?>
                            </label>
                        </th>

                        <td>
                            <input
                                type="password"
                                id="controlpact_api_key"
                                name="controlpact_api_key"
                                class="regular-text"
                                value=""
                                autocomplete="new-password"
                                placeholder="<?php
                                    echo esc_attr(
                                        $has_key
                                            ? __( 'Saved — enter a new key only to replace it', 'controlpact-governance' )
                                            : 'cpk_...'
                                    );
                                ?>"
                            >

                            <p class="description">
                                <?php esc_html_e( 'Stored server-side in WordPress. The key is never printed back into the browser after saving.', 'controlpact-governance' ); ?>
                            </p>
                        </td>
                    </tr>
                </table>

                <?php submit_button( __( 'Save Connection', 'controlpact-governance' ) ); ?>
            </form>

            <hr>

            <h2><?php esc_html_e( 'Connection Test', 'controlpact-governance' ); ?></h2>

            <p>
                <?php esc_html_e( 'This sends a real governance evaluation to ControlPact. ALLOW, APPROVE or BLOCK all confirm that the connection works.', 'controlpact-governance' ); ?>
            </p>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="controlpact_test_connection">

                <?php wp_nonce_field( 'controlpact_test_connection' ); ?>

                <?php
                submit_button(
                    __( 'Test ControlPact Connection', 'controlpact-governance' ),
                    'secondary',
                    'submit',
                    false,
                    $has_key ? array() : array( 'disabled' => 'disabled' )
                );
                ?>
            </form>

            <hr>

            <h2><?php esc_html_e( 'Governed WordPress Action', 'controlpact-governance' ); ?></h2>

            <p>
                <?php esc_html_e( 'ControlPact provides a governed REST endpoint for publishing WordPress posts. Drafts remain unpublished unless ControlPact returns ALLOW.', 'controlpact-governance' ); ?>
            </p>

            <p>
                <code>POST /wp-json/controlpact/v1/posts/{id}/publish</code>
            </p>

            <p class="description">
                <?php esc_html_e( 'Use normal WordPress REST authentication. APPROVE and BLOCK decisions leave the post unpublished.', 'controlpact-governance' ); ?>
            </p>
        </div>

        <?php
    }

    /**
     * Save the API key.
     */
    public function save_settings() {
        $this->require_admin( 'controlpact_save_settings' );

        $key = isset( $_POST['controlpact_api_key'] )
            ? trim( sanitize_text_field( wp_unslash( $_POST['controlpact_api_key'] ) ) )
            : '';

        if ( '' !== $key ) {
            if ( ! preg_match( '/^cpk_[A-Za-z0-9_-]+$/', $key ) ) {
                $this->redirect(
                    'error',
                    __( 'Enter a valid ControlPact API key beginning with cpk_.', 'controlpact-governance' )
                );
            }

            update_option( CONTROLPACT_OPTION_API_KEY, $key, false );
        }

        $this->redirect( 'saved' );
    }

    /**
     * Test the ControlPact connection.
     */
    public function test_connection() {
        $this->require_admin( 'controlpact_test_connection' );

        $api       = new ControlPact_API();
        $reference = 'wordpress-test-' . time();

        $result = $api->evaluate_action(
            'wordpress.connection.test',
            home_url( '/' ),
            array(
                'source' => 'ControlPact WordPress Plugin',
                'site'   => home_url( '/' ),
            ),
            $reference
        );

        if ( is_wp_error( $result ) ) {
            $this->redirect( 'error', $result->get_error_message() );
        }

        $decision = '';

        if ( ! empty( $result['result']['decision'] ) ) {
            $decision = strtoupper( sanitize_text_field( (string) $result['result']['decision'] ) );
        }

        if ( '' === $decision ) {
            $decision = __( 'CONNECTED', 'controlpact-governance' );
        }

        $this->redirect( 'connected', $decision );
    }

    /**
     * Verify capability and nonce for admin POST actions.
     *
     * @param string $nonce_action Nonce action name.
     */
    private function require_admin( $nonce_action ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to manage ControlPact settings.', 'controlpact-governance' ) );
        }

        check_admin_referer( $nonce_action );
    }

    /**
     * Redirect back to the settings page with a notice.
     *
     * @param string $notice  Notice type.
     * @param string $message Optional message.
     */
    private function redirect( $notice, $message = '' ) {
        $url = add_query_arg(
            array(
                'page'                 => 'controlpact',
                'controlpact_notice'   => sanitize_key( $notice ),
                'controlpact_decision' => sanitize_text_field( $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }
}
