<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class ControlPact_API {
    /**
     * ControlPact API key.
     *
     * @var string
     */
    private $api_key;

    /**
     * Create an API client.
     *
     * @param string|null $api_key Optional API key override.
     */
    public function __construct( $api_key = null ) {
        $this->api_key = null !== $api_key
            ? trim( (string) $api_key )
            : trim( (string) get_option( CONTROLPACT_OPTION_API_KEY, '' ) );
    }

    /**
     * Whether an API key is configured.
     *
     * @return bool
     */
    public function has_api_key() {
        return '' !== $this->api_key;
    }

    /**
     * Evaluate an action with ControlPact.
     *
     * @param string $action       Action name.
     * @param string $resource     Optional governed resource.
     * @param array  $context      Optional request context.
     * @param string $reference_id Optional idempotency/reference identifier.
     * @return array|WP_Error
     */
    public function evaluate_action( $action, $resource = '', array $context = array(), $reference_id = '' ) {
        if ( ! $this->has_api_key() ) {
            return new WP_Error(
                'controlpact_missing_key',
                __( 'No ControlPact API key is configured.', 'controlpact-governance' )
            );
        }

        $request = array(
            'action' => sanitize_text_field( (string) $action ),
        );

        if ( '' !== $resource ) {
            $request['resource'] = sanitize_text_field( (string) $resource );
        }

        if ( '' !== $reference_id ) {
            $request['referenceId'] = sanitize_text_field( (string) $reference_id );
        }

        if ( ! empty( $context ) ) {
            $request['context'] = $context;
        }

        $response = wp_remote_post(
            CONTROLPACT_API_BASE_URL . '/v1/decisions',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->api_key,
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',
                ),
                'body'    => wp_json_encode(
                    array(
                        'request' => $request,
                    )
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $status = (int) wp_remote_retrieve_response_code( $response );
        $body   = (string) wp_remote_retrieve_body( $response );
        $json   = json_decode( $body, true );

        if ( $status < 200 || $status >= 300 ) {
            $message = sprintf(
                /* translators: %d: HTTP status code returned by ControlPact. */
                __( 'ControlPact API request failed with HTTP %d.', 'controlpact-governance' ),
                $status
            );

            if ( is_array( $json ) ) {
                if ( ! empty( $json['error'] ) ) {
                    $message .= ' ' . sanitize_text_field( (string) $json['error'] );
                } elseif ( ! empty( $json['message'] ) ) {
                    $message .= ' ' . sanitize_text_field( (string) $json['message'] );
                }
            }

            return new WP_Error(
                'controlpact_api_error',
                $message,
                array( 'status' => $status )
            );
        }

        if ( ! is_array( $json ) ) {
            return new WP_Error(
                'controlpact_invalid_response',
                __( 'ControlPact returned invalid JSON.', 'controlpact-governance' )
            );
        }

        return $json;
    }
}
