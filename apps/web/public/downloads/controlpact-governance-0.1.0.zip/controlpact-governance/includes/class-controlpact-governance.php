<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WordPress actions governed by ControlPact.
 */
final class ControlPact_Governance {
    /**
     * Register REST routes.
     */
    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    /**
     * Register the governed post-publish endpoint.
     *
     * An authenticated WordPress REST client can create or edit a draft using
     * normal WordPress endpoints, then call this endpoint to request governed
     * publication through ControlPact.
     */
    public function register_routes() {
        register_rest_route(
            'controlpact/v1',
            '/posts/(?P<id>\d+)/publish',
            array(
                'methods'             => 'POST',
                'callback'            => array( $this, 'publish_post' ),
                'permission_callback' => array( $this, 'can_publish_post' ),
                'args'                => array(
                    'id' => array(
                        'description'       => __( 'Post ID to publish after ControlPact approval.', 'controlpact-governance' ),
                        'type'              => 'integer',
                        'required'          => true,
                        'sanitize_callback' => 'absint',
                        'validate_callback' => static function ( $value ) {
                            return is_numeric( $value ) && (int) $value > 0;
                        },
                    ),
                ),
            )
        );
    }

    /**
     * Check WordPress permissions for the governed publish operation.
     *
     * @param WP_REST_Request $request REST request.
     * @return bool|WP_Error
     */
    public function can_publish_post( $request ) {
        $post_id = absint( $request['id'] );
        $post    = get_post( $post_id );

        if ( ! $post || 'post' !== $post->post_type ) {
            return new WP_Error(
                'controlpact_post_not_found',
                __( 'The requested WordPress post could not be found.', 'controlpact-governance' ),
                array( 'status' => 404 )
            );
        }

        if ( ! current_user_can( 'edit_post', $post_id ) || ! current_user_can( 'publish_posts' ) ) {
            return new WP_Error(
                'controlpact_forbidden',
                __( 'You do not have permission to publish this post.', 'controlpact-governance' ),
                array( 'status' => 403 )
            );
        }

        return true;
    }

    /**
     * Ask ControlPact for a decision and publish only when the result is ALLOW.
     *
     * @param WP_REST_Request $request REST request.
     * @return WP_REST_Response|WP_Error
     */
    public function publish_post( $request ) {
        $post_id = absint( $request['id'] );
        $post    = get_post( $post_id );

        if ( ! $post || 'post' !== $post->post_type ) {
            return new WP_Error(
                'controlpact_post_not_found',
                __( 'The requested WordPress post could not be found.', 'controlpact-governance' ),
                array( 'status' => 404 )
            );
        }

        $api = new ControlPact_API();

        if ( ! $api->has_api_key() ) {
            return new WP_Error(
                'controlpact_not_configured',
                __( 'ControlPact is not configured for this WordPress site.', 'controlpact-governance' ),
                array( 'status' => 503 )
            );
        }

        $reference_id = 'wordpress-post-publish-' . wp_generate_uuid4();
        $resource     = 'wordpress:post:' . $post_id;
        $context      = array(
            'source'          => 'WordPress REST API',
            'site'            => home_url( '/' ),
            'postId'          => $post_id,
            'postType'        => 'post',
            'requestedStatus' => 'publish',
            'userId'          => get_current_user_id(),
        );

        $result = $api->evaluate_action(
            'wordpress.post.publish',
            $resource,
            $context,
            $reference_id
        );

        if ( is_wp_error( $result ) ) {
            return new WP_Error(
                'controlpact_evaluation_failed',
                $result->get_error_message(),
                array( 'status' => 502 )
            );
        }

        $decision = isset( $result['result']['decision'] )
            ? strtoupper( sanitize_text_field( (string) $result['result']['decision'] ) )
            : '';

        $receipt_id = '';
        if ( isset( $result['receipt']['payload']['receiptId'] ) ) {
            $receipt_id = sanitize_text_field( (string) $result['receipt']['payload']['receiptId'] );
        }

        if ( 'ALLOW' === $decision ) {
            $updated = wp_update_post(
                array(
                    'ID'          => $post_id,
                    'post_status' => 'publish',
                ),
                true
            );

            if ( is_wp_error( $updated ) ) {
                return $updated;
            }

            return rest_ensure_response(
                array(
                    'success'   => true,
                    'decision'  => 'ALLOW',
                    'postId'    => $post_id,
                    'status'    => 'publish',
                    'receiptId' => $receipt_id,
                )
            );
        }

        if ( 'APPROVE' === $decision ) {
            return new WP_Error(
                'controlpact_approval_required',
                __( 'ControlPact requires human approval before this post can be published.', 'controlpact-governance' ),
                array(
                    'status'    => 409,
                    'decision'  => 'APPROVE',
                    'receiptId' => $receipt_id,
                )
            );
        }

        if ( 'BLOCK' === $decision ) {
            return new WP_Error(
                'controlpact_blocked',
                __( 'ControlPact blocked publication of this post.', 'controlpact-governance' ),
                array(
                    'status'    => 403,
                    'decision'  => 'BLOCK',
                    'receiptId' => $receipt_id,
                )
            );
        }

        return new WP_Error(
            'controlpact_unknown_decision',
            __( 'ControlPact returned an unsupported governance decision.', 'controlpact-governance' ),
            array( 'status' => 502 )
        );
    }
}
