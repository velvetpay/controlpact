<?php
/**
 * Plugin Name: ControlPact Governance
 * Description: Connects WordPress to ControlPact for governed AI and automation decisions.
 * Version: 0.1.0
 * Author: ControlPact
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: controlpact-governance
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'CONTROLPACT_VERSION', '0.1.0' );
define( 'CONTROLPACT_API_BASE_URL', 'https://controlpact-backend.onrender.com' );
define( 'CONTROLPACT_OPTION_API_KEY', 'controlpact_api_key' );
define( 'CONTROLPACT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

require_once CONTROLPACT_PLUGIN_DIR . 'includes/class-controlpact-api.php';
require_once CONTROLPACT_PLUGIN_DIR . 'includes/class-controlpact-governance.php';
require_once CONTROLPACT_PLUGIN_DIR . 'includes/class-controlpact-admin.php';

add_action(
    'plugins_loaded',
    static function () {
        new ControlPact_Governance();

        if ( is_admin() ) {
            new ControlPact_Admin();
        }
    }
);
