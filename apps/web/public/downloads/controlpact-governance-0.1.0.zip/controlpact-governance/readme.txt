=== ControlPact Governance ===
Contributors: ctrlpact
Tags: ai, governance, automation, security, policy
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect WordPress to ControlPact and govern automated post publication with ALLOW, APPROVE or BLOCK decisions.

== Description ==

ControlPact Governance connects WordPress to the external ControlPact AI-agent governance service.

Each WordPress administrator supplies their own scoped ControlPact API credential. No shared or developer-owned production credential is bundled with the plugin.

ControlPact evaluates governed actions and returns one of three decisions:

* ALLOW
* APPROVE
* BLOCK

Version 0.1.0 includes a real governed WordPress operation for REST-based automation: an authenticated client can request publication of an existing draft post through the ControlPact endpoint. The post is published only when ControlPact returns ALLOW. APPROVE and BLOCK leave the post unpublished.

Governed endpoint:

`POST /wp-json/controlpact/v1/posts/{id}/publish`

The endpoint uses normal WordPress REST authentication and WordPress capability checks. The ControlPact API key remains stored server-side.

== External Service ==

This plugin connects to the external ControlPact governance service.

ControlPact service website:
https://ctrlpact.com

Privacy Policy:
https://ctrlpact.com/privacy

Terms of Service:
https://ctrlpact.com/terms

Current API service endpoint:
https://controlpact-backend.onrender.com

The external service is required for governance evaluations. The plugin does not perform ControlPact policy evaluation locally.

When a governance evaluation is requested, the plugin may send:

* The requested action name.
* The governed resource.
* A unique reference ID.
* Context associated with the request.
* The WordPress site URL.
* For governed post publication: the post ID, post type, requested status and current WordPress user ID.
* The configured ControlPact API credential in the HTTP Authorization header.

The governed post-publish endpoint does not send the post title or post content to ControlPact.

The API credential is used only to authenticate requests to ControlPact.

No governance request is sent until a WordPress administrator has configured the plugin with a ControlPact API credential and uses functionality that requires a ControlPact decision.

== Privacy ==

The ControlPact API key is stored server-side in the WordPress options database and is not printed back into the administration interface after it has been saved.

The option is configured not to autoload with ordinary WordPress requests.

ControlPact Governance does not include advertising or unrelated tracking.

When governance functionality is used, information necessary to evaluate the requested action is transmitted to the external ControlPact service as described in the External Service section above.

Site administrators are responsible for ensuring that the contextual data they send through governed actions is appropriate for their organisation and applicable privacy requirements.

== Installation ==

1. Install and activate ControlPact Governance.
2. Open Settings > ControlPact.
3. Enter your own scoped ControlPact API key.
4. Click Save Connection.
5. Click Test ControlPact Connection.
6. An ALLOW, APPROVE or BLOCK response confirms that ControlPact evaluated the request.
7. For governed automation, create or edit a draft using the normal WordPress REST API, then POST to `/wp-json/controlpact/v1/posts/{id}/publish` using normal WordPress REST authentication.

== Frequently Asked Questions ==

= Does the plugin include a ControlPact API key? =

No. Every installation uses the customer's own scoped ControlPact API key.

= What WordPress action is governed in version 0.1.0? =

The plugin provides a governed REST endpoint for publishing an existing WordPress post. ControlPact evaluates the `wordpress.post.publish` action before publication.

= What happens when ControlPact returns ALLOW? =

The requested post is published and the endpoint returns the ControlPact decision and receipt ID.

= What happens when ControlPact returns APPROVE or BLOCK? =

The post remains unpublished. APPROVE returns an approval-required response and BLOCK returns a blocked response.

= Does installing the plugin automatically provide Production access? =

No. Access is determined by the customer's ControlPact account, organisation, entitlement and API credential.

= Is ControlPact required? =

Yes. This plugin is an integration with the external ControlPact governance service.

== Changelog ==

= 0.1.0 =
* Initial public release.
* Added server-side ControlPact connection.
* Added administrator-only API credential configuration.
* Added real governance connection testing.
* Added a governed REST endpoint for publishing WordPress posts.
* Added ALLOW, APPROVE and BLOCK enforcement for governed publication.
